import '../styles/styles.css'

const Footer = () => {
  return (
    <div className='footer'>
      <div className='inner-footer'>
        <p style={{color: 'white', fontSize: 18, paddingTop: 15, paddingBottom: 10, marginLeft: 20}}>Devops Demo</p>
      </div>
    </div>
  )
}

export default Footer