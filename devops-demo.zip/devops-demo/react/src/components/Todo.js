import '../styles/styles.css'

const Todo = () => {
  return (
    <div className='block-div'>
      <div className='todo-top'>
        <input type='text' className='input' placeholder='New Item'/>
        <button className='button'>Add Item</button>
      </div>
    </div>
  )
}

const Item = () => {

}

export default Todo