# Express server
- Connects to mongodb docker container at `http://localhost:1000`
- Can use mongo-express docker container to view database at [http://localhost:8081]()